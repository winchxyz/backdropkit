# Sunfield

A BackdropKit theme for the Claude desktop app: an animated pixel-art sky over a sunflower field
behind your Claude Code conversation. It follows your computer's clock, from night through
sunrise, day and sunset, and the app's panels follow the sky.

Made by the BackdropKit community project (https://github.com/winchxyz/backdropkit). Not made by Anthropic.

## What is inside

- `.claude-plugin/marketplace.json`: a marketplace with one plugin, named `backdropkit-sunfield`.
- `mod/.claude-plugin/plugin.json`: the plugin, named `sunfield`.
- `mod/hooks/colors.d.ts`: type declarations for colors.js.
- `mod/hooks/colors.js`: the colours and the frosted glass over the scene.
- `mod/hooks/day.d.ts`: type declarations for day.js.
- `mod/hooks/day.js`: sunrise and sunset from the clock and time zone, the look of each moment, and the CSS of the day.
- `mod/hooks/hooks.json`: names register.tsx as the module to load.
- `mod/hooks/make-colors.d.ts`: type declarations for make-colors.js.
- `mod/hooks/make-colors.js`: Anthropic's colour helper, copied from Claude Code's plugin-authoring skill.
- `mod/hooks/register.test.tsx`: tests for register.tsx (claude plugin test mod).
- `mod/hooks/register.tsx`: sets the theme when a session starts, writes the scene for the time of day, and adds /sunfield-off, /sunfield-on and /sunfield-sky.
- `mod/hooks/scene.d.ts`: type declarations for scene.js.
- `mod/hooks/scene.js`: the scene: one animated pixel-art SVG, as a string.
- `preview.png`: the theme at day.
- `project.json`: the theme's project file for the BackdropKit editor (empty for now).
- `README.md`: this file.

Nothing else belongs in the archive. The plugin reads no files and makes no network requests.

## Install by hand

Unpack the archive into a folder you keep (the theme is read from it), for example
`~/.claude/backdropkit/sunfield`, then run these two commands with that folder's path:

```
claude plugin marketplace add "<that folder>"
claude plugin install sunfield@backdropkit-sunfield --scope user
```

Run /reload-plugins or start a new session to see the theme.

## Use

- `/sunfield-sky` shows today's sunrise and sunset; `/sunfield-sky sunset` (or night, dawn,
  sunrise, morning, day, golden, dusk, twilight, or a time like 18:30) previews another time;
  `/sunfield-sky now` goes back to your clock.
- `/sunfield-off` takes the theme off, `/sunfield-on` puts it back.
- To remove it: `claude plugin uninstall sunfield@backdropkit-sunfield`.

The app plays the motion only with the GPU on and reduced motion off; otherwise it shows a
still frame of the current time of day.
