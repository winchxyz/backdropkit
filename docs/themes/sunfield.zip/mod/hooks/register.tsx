// Sunfield: a pixel-art sky over a sunflower field behind the conversation, with the app's
// colours to match. The sky follows the computer's clock: stars and a moon at night, dawn,
// day, a low sun at sunset, dusk. The app's frosted panels follow it too: tinted from the
// sky of the moment, light with dark words by day and dark with pale words by night. The
// desktop and mobile apps draw it; the terminal keeps its own look. /sunfield-off takes it
// off (in new sessions too), /sunfield-on puts it back, /sunfield-sky shows today's sunrise
// and sunset or previews another time of day.
import type { Register, ThemeSetArgs } from 'claude-code'

import { BLUR, COLORS, NIGHT_COLORS } from './colors.js'
import { MOMENTS, clock, paneAt, sceneAt, secondsOfDay, sunTimes } from './day.js'
import { makeColors } from './make-colors.js'
import { SCENE } from './scene.js'

const SCENE_ID = 'sunfield'
const ALT = 'A pixel-art sky over a sunflower field at the time of day: a tall cloud, birds, a plane drawing a contrail, sunflowers swaying in the wind, and stars and a moon at night'

const DAY = makeColors(COLORS)
const NIGHT = makeColors(NIGHT_COLORS)

// The whole theme for the moment `ms`: the colours of its kind (day or night) and the glass
// tinted from its sky.
function lookAt(ms: number): ThemeSetArgs {
  const pane = paneAt(ms)
  return {
    colors: (pane.dark ? NIGHT : DAY).theme,
    overrideColorScheme: pane.dark ? 'dark' : 'light',
    backdrop: { scene: SCENE_ID, glass: { blur: BLUR, tint: pane.tint, opacity: pane.opacity } },
  }
}

// How often the scene and the glass are written afresh, so a picture the app restarts (it
// does when the window is resized) is never more than this far behind the clock.
const RESYNC_MS = 5 * 60 * 1000

// The time: read from the engine's clock now and then and carried on in between, so drawing
// never waits. `shift` moves it for /sunfield-sky.
let clockAt = Date.now()
let perfAt = performance.now()
let shift = 0
const now = () => clockAt + (performance.now() - perfAt) + shift

// Whether the person took the theme off, and the glass last set, so it is set again only
// when the moment changes it.
let off = false
let lastPane = ''

// The theme for this moment when it differs from the one last set (always, with `force`),
// else undefined; it counts as set from here.
function changedLook(force = false): ThemeSetArgs | undefined {
  if (off) return undefined
  const look = lookAt(now())
  const key = JSON.stringify(look.backdrop)
  if (!force && key === lastPane) return undefined
  lastPane = key
  return look
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'sunfield-off', description: 'Take the Sunfield theme off' })
    await $.command.register({ name: 'sunfield-on', description: 'Put the Sunfield theme back on' })
    await $.command.register({
      name: 'sunfield-sky',
      description: "Show today's sunrise and sunset, or preview the sky at another time",
      argumentHint: '[night|dawn|sunrise|day|golden|sunset|dusk|HH:MM|now]',
    })
    try {
      clockAt = await $.clock.now()
      perfAt = performance.now()
    } catch {
      // Keep the time read when the module loaded.
    }
    try {
      off = (await $.store.get('off')) === true
    } catch {
      off = false
    }
    $.clock.every(RESYNC_MS, () => {
      $.clock
        .now()
        .then(ms => {
          clockAt = ms
          perfAt = performance.now()
        })
        .catch(() => undefined)
        .then(() => {
          const look = changedLook()
          return look === undefined ? undefined : $.theme.set(look)
        })
        .catch(() => undefined)
        .finally(() => $.ui.invalidate('ui.render'))
    })
    if (!off) {
      // The line that would stop Desktop painting the colours, if a change ever brings one.
      const unpainted = [...DAY.problems, ...NIGHT.problems].find(line => line.startsWith("Desktop won't paint"))
      if (unpainted !== undefined) $.ui.toast(unpainted)
      // No status line from the result: at start (and on a reload) the app is often not attached
      // yet, so the set reports "no attached desktop or mobile client" while the app goes on to
      // draw the theme once it attaches.
      const look = changedLook(true)
      if (look !== undefined) await $.theme.set(look)
    }
    $.ui.status(undefined)
    return next(e)
  })

  // The backdrop is the one Svg, alone: the desktop app plays a moving scene of that shape
  // itself, as a picture it redraws with the scene's own CSS motion, and keeps the still
  // frame (the same scene with the motion taken out) for reduced motion and slow machines.
  // The scene is written for this moment each time it is drawn.
  on('ui.render', { component: 'Backdrop' }, ($, e, next) => {
    if (e.props.plugin !== $.plugin.name || e.props.scene !== SCENE_ID) return next(e)
    if (e.surface !== 'desktop' && e.surface !== 'mobile') return next(e)
    const { Svg } = $.ui.resolve(e)
    return <Svg source={sceneAt(SCENE, now())} alt={ALT} isInteractive />
  })

  // /sunfield-sky: today's sunrise and sunset; with a moment or a time, the sky and the glass
  // jump there and run on from it until /sunfield-sky now.
  on('command.run', { command: 'sunfield-sky' }, async ($, e) => {
    const arg = e.args.trim().toLowerCase()
    const real = clockAt + (performance.now() - perfAt)
    const { rise, set } = sunTimes(real)
    const today = 'Today by your clock: sunrise ' + clock(rise) + ', sunset ' + clock(set) + '.'
    const choices = Object.keys(MOMENTS).join(', ')
    if (arg === '' || arg === 'now') {
      if (shift !== 0) {
        shift = 0
        const look = changedLook()
        if (look !== undefined) await $.theme.set(look)
        $.ui.invalidate('ui.render')
      }
      return { text: 'Sunfield follows your clock. ' + today + ' To preview: /sunfield-sky ' + choices + ', or a time like 18:30.' }
    }
    let minute: number | undefined
    const moment = MOMENTS[arg]
    if (moment !== undefined) minute = (moment[0] === 'r' ? rise : set) + moment[1]
    const hm = /^(\d{1,2}):(\d{2})$/.exec(arg)
    if (hm !== null) {
      const h = Number(hm[1] ?? '')
      const m = Number(hm[2] ?? '')
      if (h < 24 && m < 60) minute = h * 60 + m
    }
    if (minute === undefined) return { text: 'No such time: "' + arg + '". Try ' + choices + ', a time like 18:30, or now.' }
    shift = (minute * 60 - secondsOfDay(real)) * 1000
    const look = changedLook()
    if (look !== undefined) await $.theme.set(look)
    $.ui.invalidate('ui.render')
    return { text: 'The sky shows ' + clock(minute) + ' and runs on from there. ' + today + ' /sunfield-sky now goes back to your clock.' }
  })

  on('command.run', { command: 'sunfield-off' }, async $ => {
    let kept = true
    try {
      await $.store.set('off', true)
    } catch {
      kept = false
    }
    off = true
    lastPane = ''
    await $.theme.clear()
    return { text: kept ? 'Sunfield is off, in new sessions too. /sunfield-on puts it back.' : 'Sunfield is off in this session.' }
  })

  on('command.run', { command: 'sunfield-on' }, async $ => {
    try {
      await $.store.delete('off')
    } catch {
      // Nothing stored: it was on already.
    }
    off = false
    const set = await $.theme.set(changedLook(true) ?? lookAt(now()))
    return { text: set.isDrawn ? 'Sunfield is on.' : 'Sunfield is set, but nothing draws it here: ' + set.reason }
  })
}
