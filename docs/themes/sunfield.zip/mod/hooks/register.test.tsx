import type { On } from 'claude-code'
import { expect, mock, test } from 'claude-code/testing'

import { PANES, sunTimes } from './day.js'

const BACKDROP = { plugin: 'sunfield', component: 'Backdrop', props: { plugin: 'sunfield', scene: 'sunfield', glass: false } } as const
// A slash command as the person types it.
const typed = (command: string, args: string) => ({ command, args, origin: { kind: 'composer' as const }, presentation: { isFullscreen: false, columns: 80 } })

// What the session start asks of the engine, answered as the engine would. Each theme set is
// kept, as JSON, in `sets`.
function engine(on: On, sets: string[] = []) {
  on('session.start', (_, e) => ({ cwd: e.cwd }))
  on('command.register', (_, e) => ({ value: { command: e.name } }))
  on('theme.set', (_, e) => {
    sets.push(JSON.stringify(e))
    return { value: { isDrawn: true as const, requestId: 'theme' } }
  })
  on('ui.status', () => ({ value: undefined }))
}

// The scene's --t, in seconds.
async function shownSeconds(ui: { drawn: () => Promise<unknown> }) {
  const tree = (await ui.drawn()) as { type: string; props: { source: string } }
  expect(tree.type).toBe('Svg')
  const t = /--t:-([\d.]+)s/.exec(tree.props.source)
  expect(t).not.toBeNull()
  return { seconds: Number(t?.[1]), source: tree.props.source }
}

test('the sky is written for the local time of the clock', async ($, on) => {
  const at = new Date(2026, 10, 15, 16, 30).getTime()
  mock.clock(on, { now: at })
  mock.store(on)
  engine(on)
  await $.session.start({ cwd: '/', surface: 'desktop', isInteractive: true })

  const ui = await $.ui.mount({ ...BACKDROP, surface: 'desktop' })
  const { seconds, source } = await shownSeconds(ui)
  // 16:30 is 59400 s after midnight; the scene leads by a fifth of a second.
  expect(Math.abs(seconds - 59400.2)).toBeLessThan(1)
  expect(source).toContain('@keyframes N{')
  expect(source).not.toContain('/*D*/')
  await ui.unmount()
})

test('the panels are light by day and dark at night, tinted from the sky', async ($, on) => {
  const sets: string[] = []
  mock.clock(on, { now: new Date(2026, 10, 15, 12, 0).getTime() })
  mock.store(on)
  engine(on, sets)
  await $.session.start({ cwd: '/', surface: 'desktop', isInteractive: true })
  expect(sets.length).toBe(1)
  expect(sets[0]).toContain('"overrideColorScheme":"light"')
  expect(sets[0]).toContain(PANES.day?.tint ?? '-')

  // The preview moves the glass with the sky: to the dark night look and back.
  await $.command.run(typed('sunfield-sky', '02:00'))
  expect(sets.length).toBe(2)
  expect(sets[1]).toContain('"overrideColorScheme":"dark"')
  expect(sets[1]).toContain(PANES.night?.tint ?? '-')
  await $.command.run(typed('sunfield-sky', 'now'))
  expect(sets.length).toBe(3)
  expect(sets[2]).toContain('"overrideColorScheme":"light"')
})

test('/sunfield-sky moves the sky to a moment and back', async ($, on) => {
  const at = new Date(2026, 10, 15, 11, 0).getTime()
  mock.clock(on, { now: at })
  mock.store(on)
  engine(on)
  await $.session.start({ cwd: '/', surface: 'desktop', isInteractive: true })

  const said = await $.command.run(typed('sunfield-sky', 'sunset'))
  expect(said.text).toContain('The sky shows')
  const ui = await $.ui.mount({ ...BACKDROP, surface: 'desktop' })
  const { set } = sunTimes(at)
  expect(Math.abs((await shownSeconds(ui)).seconds - ((set - 10) * 60 + 0.2))).toBeLessThan(2)

  const back = await $.command.run(typed('sunfield-sky', 'now'))
  expect(back.text).toContain('follows your clock')
  expect(Math.abs((await shownSeconds(ui)).seconds - (11 * 3600 + 0.2))).toBeLessThan(2)
  await ui.unmount()
})
