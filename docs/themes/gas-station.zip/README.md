# Gas Station

A BackdropKit theme for the Claude desktop app: a roadside gas station whose price board shows your Claude figures. A desert gas station by the highway. Its price board shows this chat's tokens, how full the context is and how much of the weekly limit is used. Clouds drift, a pickup passes now and then, and at night moths circle the canopy lights.

It is an animated pixel-art scene behind your Claude Code conversation, with the app's colours
to match. It follows your computer's clock, with one scene for each part of the day:

| Scene | From | To | Panels |
| --- | --- | --- | --- |
| Day | 06:00 | 17:00 | light |
| Sunset | 17:00 | 21:00 | dark |
| Night | 21:00 | 06:00 | dark |

The scene changes within five minutes of its hour, and the app's panels change with it: light
with dark words over a light scene, dark with pale words over a dark one, the frosted glass
tinted from the scene.

## The price board

The sign shows three live figures instead of prices:

- the tokens this chat has used, as the API counts them (cache reads included), counted from
  the first turn the theme saw in it;
- how full the context window is;
- how much of your weekly usage limit is used (dashes until the first answer reports it, or
  when you are not on a subscription).

They come from the app's own usage figures and are drawn into the scene as pixel digits;
nothing leaves your computer. The plugin keeps each chat's token count, and the last weekly
reading, in its own store.

Made by the BackdropKit community project (https://github.com/winchxyz/backdropkit). Not made by Anthropic.

## What is inside

- `.claude-plugin/marketplace.json`: a marketplace with one plugin, named `backdropkit-gas-station`.
- `mod/.claude-plugin/plugin.json`: the plugin, named `gas-station`, version 0.1.0.
- `mod/hooks/board.d.ts`: type declarations for board.js.
- `mod/hooks/board.js`: the price board: a theme's live figures drawn into its scene as pixel digits (used by themes with a board).
- `mod/hooks/colors.d.ts`: type declarations for colors.js.
- `mod/hooks/colors.js`: the colours of the light and the dark look, and the blur of the frosted glass.
- `mod/hooks/hooks.json`: names register.tsx as the module to load.
- `mod/hooks/make-colors.d.ts`: type declarations for make-colors.js.
- `mod/hooks/make-colors.js`: Anthropic's colour helper, copied from Claude Code's plugin-authoring skill.
- `mod/hooks/register.test.tsx`: tests for register.tsx (claude plugin test mod).
- `mod/hooks/register.tsx`: sets the theme when a session starts, picks the scene for the time of day, and adds /gas-station-off, /gas-station-on and /gas-station-time.
- `mod/hooks/theme.d.ts`: type declarations for theme.js.
- `mod/hooks/theme.js`: the theme: its moments, the hour each starts, the panels' tone and glass over each, and each scene as one animated SVG string.
- `preview.png`: a still of the Day scene.
- `project.json`: the theme's project file for the BackdropKit editor (empty for now).
- `README.md`: this file.

Nothing else belongs in the archive. The plugin reads no files and makes no network requests.

## Install by hand

Unpack the archive into a folder you keep (the theme is read from it), for example
`~/.claude/backdropkit/gas-station`, then run these two commands with that folder's path:

```
claude plugin marketplace add "<that folder>"
claude plugin install gas-station@backdropkit-gas-station --scope user
```

Run /reload-plugins or start a new session to see the theme. If another theme plugin is on,
turn it off first (`claude plugin disable <name>`): the theme set last wins.

## Use

- `/gas-station-time` lists when each scene plays. `/gas-station-time night` (or day, sunset, or a
  time like 18:30) previews another moment and runs on from it; `/gas-station-time now` goes back
  to your clock.
- `/gas-station-off` takes the theme off, in new sessions too; `/gas-station-on` puts it back.
- To remove it: `claude plugin uninstall gas-station@backdropkit-gas-station`.

The app plays the motion only with the GPU on and reduced motion off; otherwise it shows a
still frame of the scene.
