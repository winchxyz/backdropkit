# Tide Line

A BackdropKit theme for the Claude desktop app: a low view from the beach. Waves roll in and leave foam on shining wet sand.

It is an animated pixel-art scene behind your Claude Code conversation, with the app's colours
to match. It follows your computer's clock, with one scene for each part of the day:

| Scene | From | To | Panels |
| --- | --- | --- | --- |
| Sunrise | 05:00 | 17:00 | dark |
| Sunset | 17:00 | 21:00 | dark |
| Night | 21:00 | 05:00 | dark |

The scene changes within five minutes of its hour, and the app's panels change with it: light
with dark words over a light scene, dark with pale words over a dark one, the frosted glass
tinted from the scene.

Made by the BackdropKit community project (https://github.com/winchxyz/backdropkit). Not made by Anthropic.

## What is inside

- `.claude-plugin/marketplace.json`: a marketplace with one plugin, named `backdropkit-tide-line`.
- `mod/.claude-plugin/plugin.json`: the plugin, named `tide-line`, version 0.1.0.
- `mod/hooks/colors.d.ts`: type declarations for colors.js.
- `mod/hooks/colors.js`: the colours of the light and the dark look, and the blur of the frosted glass.
- `mod/hooks/hooks.json`: names register.tsx as the module to load.
- `mod/hooks/make-colors.d.ts`: type declarations for make-colors.js.
- `mod/hooks/make-colors.js`: Anthropic's colour helper, copied from Claude Code's plugin-authoring skill.
- `mod/hooks/register.test.tsx`: tests for register.tsx (claude plugin test mod).
- `mod/hooks/register.tsx`: sets the theme when a session starts, picks the scene for the time of day, and adds /tide-line-off, /tide-line-on and /tide-line-time.
- `mod/hooks/theme.d.ts`: type declarations for theme.js.
- `mod/hooks/theme.js`: the theme: its moments, the hour each starts, the panels' tone and glass over each, and each scene as one animated SVG string.
- `preview.png`: a still of the Sunrise scene.
- `project.json`: the theme's project file for the BackdropKit editor (empty for now).
- `README.md`: this file.

Nothing else belongs in the archive. The plugin reads no files and makes no network requests.

## Install by hand

Unpack the archive into a folder you keep (the theme is read from it), for example
`~/.claude/backdropkit/tide-line`, then run these two commands with that folder's path:

```
claude plugin marketplace add "<that folder>"
claude plugin install tide-line@backdropkit-tide-line --scope user
```

Run /reload-plugins or start a new session to see the theme. If another theme plugin is on,
turn it off first (`claude plugin disable <name>`): the theme set last wins.

## Use

- `/tide-line-time` lists when each scene plays. `/tide-line-time night` (or sunrise, sunset, or a
  time like 18:30) previews another moment and runs on from it; `/tide-line-time now` goes back
  to your clock.
- `/tide-line-off` takes the theme off, in new sessions too; `/tide-line-on` puts it back.
- To remove it: `claude plugin uninstall tide-line@backdropkit-tide-line`.

The app plays the motion only with the GPU on and reduced motion off; otherwise it shows a
still frame of the scene.
