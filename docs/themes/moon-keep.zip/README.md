# Moon Keep

A BackdropKit theme for the Claude desktop app: a castle of spires under a full moon. Gothic spires on a crag in a cold blue night.

It is an animated pixel-art scene behind your Claude Code conversation, with the app's colours
to match. It is the same at every hour: one scene, all day.

Made by the BackdropKit community project (https://github.com/winchxyz/backdropkit). Not made by Anthropic.

## What is inside

- `.claude-plugin/marketplace.json`: a marketplace with one plugin, named `backdropkit-moon-keep`.
- `mod/.claude-plugin/plugin.json`: the plugin, named `moon-keep`, version 0.1.0.
- `mod/hooks/board.d.ts`: type declarations for board.js.
- `mod/hooks/board.js`: the price board: a theme's live figures drawn into its scene as pixel digits (used by themes with a board).
- `mod/hooks/colors.d.ts`: type declarations for colors.js.
- `mod/hooks/colors.js`: the colours of the light and the dark look, and the blur of the frosted glass.
- `mod/hooks/hooks.json`: names register.tsx as the module to load.
- `mod/hooks/make-colors.d.ts`: type declarations for make-colors.js.
- `mod/hooks/make-colors.js`: Anthropic's colour helper, copied from Claude Code's plugin-authoring skill.
- `mod/hooks/register.test.tsx`: tests for register.tsx (claude plugin test mod).
- `mod/hooks/register.tsx`: sets the theme when a session starts, picks the scene for the time of day, and adds /moon-keep-off, /moon-keep-on and /moon-keep-time.
- `mod/hooks/theme.d.ts`: type declarations for theme.js.
- `mod/hooks/theme.js`: the theme: its moments, the hour each starts, the panels' tone and glass over each, and each scene as one animated SVG string.
- `preview.png`: a still of the scene.
- `project.json`: the theme's project file for the BackdropKit editor (empty for now).
- `README.md`: this file.

Nothing else belongs in the archive. The plugin reads no files and makes no network requests.

## Install by hand

Unpack the archive into a folder you keep (the theme is read from it), for example
`~/.claude/backdropkit/moon-keep`, then run these two commands with that folder's path:

```
claude plugin marketplace add "<that folder>"
claude plugin install moon-keep@backdropkit-moon-keep --scope user
```

Run /reload-plugins or start a new session to see the theme. If another theme plugin is on,
turn it off first (`claude plugin disable <name>`): the theme set last wins.

## Use

- `/moon-keep-off` takes the theme off, in new sessions too; `/moon-keep-on` puts it back.
- `/moon-keep-time` says when the scene plays: all day, so there is no other moment to preview.
- To remove it: `claude plugin uninstall moon-keep@backdropkit-moon-keep`.

The app plays the motion only with the GPU on and reduced motion off; otherwise it shows a
still frame of the scene.
